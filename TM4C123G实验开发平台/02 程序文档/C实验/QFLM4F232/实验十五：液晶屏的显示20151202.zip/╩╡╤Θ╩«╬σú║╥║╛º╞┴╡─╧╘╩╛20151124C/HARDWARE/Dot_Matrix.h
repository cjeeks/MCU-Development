#ifndef _DOT_MATRIX_H_
#define _DOT_MATRIX_H_

void Dot_Matric_Gpio_init(void);
void Dot_Matrix_test(void);
#endif