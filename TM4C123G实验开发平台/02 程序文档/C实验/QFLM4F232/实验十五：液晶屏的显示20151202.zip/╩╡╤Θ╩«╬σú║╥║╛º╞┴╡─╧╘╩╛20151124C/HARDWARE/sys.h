#ifndef _SYS_H_
#define _SYS_H_

#define uchar unsigned  char
#define uint unsigned int

#define u8 unsigned  char
#define u16 unsigned short
#define u32 unsigned int

#define uint8_t unsigned  char
#define uint16_t unsigned short
#define uint32_t unsigned int

#endif