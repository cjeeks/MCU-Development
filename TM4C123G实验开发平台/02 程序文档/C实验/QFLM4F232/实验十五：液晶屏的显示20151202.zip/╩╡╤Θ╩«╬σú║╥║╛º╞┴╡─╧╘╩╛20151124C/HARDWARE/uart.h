#ifndef _UART_H_
#define _UART_H_

void InitConsole(unsigned char num);

#endif