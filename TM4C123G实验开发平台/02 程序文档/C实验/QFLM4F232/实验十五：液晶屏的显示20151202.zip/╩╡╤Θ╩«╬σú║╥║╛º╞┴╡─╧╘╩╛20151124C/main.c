#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/rom.h"
#include "grlib/grlib.h"
#include "inc/hw_memmap.h"
#include "driverlib/fpu.h"

#include "hardware/lcd.h"
#include "driverlib/uart.h"
#include "hardware/relay.h"
#include "hardware/PCF8574.h"
#include "hardware/bmp085.h"
#include "hardware/DC_motor.h"
#include "hardware/dht11.h"
#include "hardware/Dot_Matrix.h"
#include "hardware/step_motor.h"
#include "hardware/MMA7455.h"
#include "hardware/tm1638.h"
#include "hardware/key.h"
 
//enable uart interrupt
#define UART_BUFFERED
 
void Delay(unsigned int x)
{
    unsigned int j,t;
    while(x--){
        for(j=0;j<190;j++)
			    for(t=0;t<180;t++);
        }   
}

static uint8_t read_val = 0;

u8 play[4]  = {0x7E, 0x02, 0x0D, 0xEF};
u8 prev[4]  = {0x7E, 0x02, 0x02, 0xEF};
u8 next[4]  = {0x7E, 0x02, 0x01, 0xEF};
u8 pause[4] = {0x7E, 0x02, 0x0E, 0xEF};

u8 mode_U[5] = 			{0x7E, 0x03, 0x09, 0, 0xEF};
u8 mode_FLASH[5] =  {0x7E, 0x03, 0x09, 4, 0xEF}; 
u8 mode_TF[5] = 		{0x7E, 0x03, 0x09, 1, 0xEF};	

int main(void)
{
    tContext sContext;
    tRectangle sRect;
	
		uint32_t i = 0;
	
    FPUEnable();						
    FPULazyStackingEnable();

    // Set the clocking to run directly from the crystal.
    SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN);

		InitConsole(3);	  
		//UART2_Int_Config();	
	
		PCF8574_I2C_GPIO_Config();
  	Dot_Matric_Gpio_Init();
		DC_Motor_GPIO_Init();
		KEY_Init();
		TM1638_GPIO_Configuration();   //IO�ڳ�ʼ��	
		Relay_Gpio_Init();
		I2C_Gpio_Init();
    lcd_init();	                  //��ʼ��LCD����

		PCF8574_Single_WriteI2C(PCF8574T_E, 0xe0);  //close DC motor[0][3]  close relay[5:7]
#if 1	
		UARTprintf(play);							//��ӭʹ��

		LCD_Clear(Black);	
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--TM4C123G Platform--");  // ʵ�鿪��ƽ̨	
		LCD_ShowString(150,60, "STEP1: KEY testing");
		LCD_ShowString(10, 200, "Press K2,K3,K4, observe LED1,LED2,LED3 "); 
		KEY_Test();						//STEP1: KEY test
			
		LCD_Clear(Black);
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--TM4C123G Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(150,60, "Step 2:RELAY Testing");		
		Relay_test();						//STEP2: RELAY test	
		Delay(10);		
			
		LCD_Clear(Black);
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--TM4C123G Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(150,60, "Step 3:STEP_Motor Testing");		
		STEP_Motor_test();			
		Delay(150);	
		
		LCD_Clear(Black);
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--TM4C123G Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(150,60, "Step 4:DC_Motor Testing");	
		DC_Motor_GPIO_Init();
		DC_Motor_test();			
		Delay(100);
	
		LCD_Clear(Black);
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--TM4C123G Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(100,60, "Step 5:Temperature and Pressure and acclerate Testing");

		while(KEY1 == 1)
		{				
			BMP085_Test();
			MMA7455_Test();	
		}
		Delay(5);		

		LCD_Clear(Black);
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--TM4C123G Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(150,60, "Step 6:Dotmatrix Testing");		
		LCD_ShowString(150,80, "Press K2 to next Test");			
		while(KEY1 == 1)	
		{				
			Dot_Matrix_test();		
		}
		//G_ONOFF(0x00000002);
		ROM_GPIOPinWrite(GPIO_PORTF_BASE, 0x00000002, 0x00000002);
		Delay(5);
	
		LCD_Clear(Black);		
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--STM32F103VCT6 Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(30,60, "STEP7: Temperature, humidity and smoke Sensor testing");
		LCD_ShowString(150,80, "Press K2 to next Test");		
		LCD_ShowString(50, 220, "Tips: Note of the information on the screen");	
		while(KEY1 == 1)	
		{				
			DHT11_Test();					//STEP3: DHT11 test	
			GAS_Test();
			HUMAN_Test();		
		}
		Delay(5);	
#endif
		LCD_Clear(Black);	
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--STM32F103VCT6 Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(150,60, "STEP9: KEYPAD testing");	
		LCD_ShowString(50, 220, "Tips: Press the keypad and note of the information on the screen");					
		TM1638Test();
			
		Delay(5);		
		LCD_Clear(Black);	
		LCD_DrawRectangle(0,5, 479, 271);
		LCD_DrawRectangle(5,18, 474, 266);
		LCD_ShowString(150, 6, "--STM32F103VCT6 Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(150,60, "STEP8: RFID testing");
		//LCD_ShowString(150,80, "Press K2 to next Test");		
		LCD_ShowString(50, 220, "Tips: Note of the information on the screen");	

		InitConsole(2);	  
		UART2_Int_Config();			
		
		while(KEY1 == 1)
		{
			RFID_Test();
		}		
		LCD_ShowString(150, 6, "--STM32F103VCT6 Platform--");  // ʵ�鿪��ƽ̨
		LCD_ShowString(150,60, "Test Complete!");		
		while(1)	
		{				
			
		}
}